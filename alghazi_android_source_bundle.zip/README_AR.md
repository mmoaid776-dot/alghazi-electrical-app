# تطبيق آل غازي للأندرويد

مشروع Android WebView يضم تطبيق HTML داخل `app/src/main/assets/index.html`.

## البناء
يتم البناء تلقائياً عبر GitHub Actions عند تشغيل سير العمل `Build Android APK`.
الناتج APK تجريبي (debug) قابل للتثبيت على جهاز Android.
